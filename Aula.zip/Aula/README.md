# atividade-09-10
Atividade utilizando o codeigniter em laboratorio

__________


# Passo a Passo para a aula pratica
    ### 1° Etapa
        - Clonar este repositorio para maquina local
        - Se for utilizar o XAMPP descompactar o repositorio dentro de htdocs
        - Inicializar os serviços do XAMPP (Mysql e Apache)
        - Acessar o endereço http://localhost/atividade-09-10
    ### 2° Etapa
        - Criar um banco de dados e uma tabela no banco local
        - Mapear o projeto no editor de texto de sua preferencia
    ### 3° Etapa
        - Configurar o projeto e desenvolver o CRUD  

